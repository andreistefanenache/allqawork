def count(sequence, item):
  y = 0
  for n in sequence:
    if n == item:
      y += 1
  return y
