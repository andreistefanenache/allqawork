USE qastore;
CREATE TABLE dbo.students (name VARCHAR(30) PRIMARY KEY, age INTEGER);