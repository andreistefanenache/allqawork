for i in range(1,101):
    print(i,i**2)
    if i**2 > 2000:
        break