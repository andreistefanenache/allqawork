# allqawork
All QA work this period

See also: https://github.com/andreistefanenache/dockerapp (Jenkins)
