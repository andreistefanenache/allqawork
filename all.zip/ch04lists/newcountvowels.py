print(sum(i in'aeiouAEIOU'for i in input())
