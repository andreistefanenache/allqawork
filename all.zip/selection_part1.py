person_age = int(input("Please enter your age"))
if person_age >= 18:
    print("You are in category A")
if person_age >= 16:
    print("You are in category B")
if person_age < 16:
    print("You are in category C")