username='Bob'
age=32
print(username+'is'+str(age)+'years old')
username=input('Please enter your name')
age = input('Please enter your age')
print(username,'is',age,'years old')

length=int(input("Please enter the length of the rectangle: "))
width=int(input("Please enter the width of the rectangle"))
print("The area is",length*width)
print("The perimeter is",length+width<<1)
# <<1 is *2 over the integers